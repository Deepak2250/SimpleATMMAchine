package com.javaoops.Practice;


class UserDetails {
    private final int accountNumber;
    private final String name;
    private int balance;
    private int depositedMoney;
    private int withdrawalMoney;

    UserDetails(int accountNumber , String name){
        this.accountNumber = accountNumber;
        this.name = name;
    }

    public void getName(){
        System.out.println("The Customer name is : "+name);
    }
    public void getAccountNumber(){
        System.out.println("Account Number is : "+accountNumber);
    }
    public void getBalance(){
        System.out.println("The Current Balance is : "+balance+"$");
    }
    ///SettingUp Deposited Money
    public int getDepositedMoney(){
       return depositedMoney;
    }
    public void setDepositedMoney(int depositedMoney){
        System.out.println("The Deposit Money is : "+depositedMoney+"$");
        this.depositedMoney = depositedMoney;
        this.balance = this.balance + this.depositedMoney;
    }
    /// Setting Up Withdrwal Money
    public int getWithdraw() {
        return withdrawalMoney;
    }

    public void setWithdrawalMoney(int withdrawAMount){
        if (withdrawAMount>=this.balance){
            System.out.println("You cannot Make any Payments");
        }
        System.out.println("You Withdraw "+withdrawAMount+"$" +" "+"from Your Bank");
        this.withdrawalMoney = withdrawAMount;
        this.balance = this.balance - this.withdrawalMoney;
    }
}
public class AtmMachine {
    public static void main(String[] args) {


    }
}
